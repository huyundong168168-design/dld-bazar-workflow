# D.L.D BAZAR — 正式测试前独立集成准备包（2026-10-19）

## 本包是什么
- `web_test/index.html`：P1-A V3 **独立浏览器测试页**，选择供应商截图 → 自动检测布局或手动修正 → 逐款确认 → 下载裁剪候选 ZIP。**不会自动把图片交给后端审核程序**。
- `offline_pipeline/`：之前已验证的固定截图模板、P5 审核、P6 规格检查及回归测试程序；没有发布接口。
- `fixtures/IMG_2971.jpeg`：用户提供的六商品供应商截图测试样本。
- `fixtures/FORTE_reference_25.zip`：用户提供的成功 25 款样本，仅用于图片及13列格式参照，**包含采购成本，只限本地私有存储，绝不上传公开 GitHub/Netlify**。
- `results/`：1、5、6 款离线审核 ZIP、自动测试报告。

## 如何在电脑本地复测
需要 Python3 和 Pillow：`python -m pip install Pillow`（如果已安装无需重复）。
在本 ZIP 解压目录运行：
`python offline_pipeline/test_integrated.py --screenshot fixtures/IMG_2971.jpeg --forte fixtures/FORTE_reference_25.zip --output-dir results`

## 手机浏览器测试
`web_test/index.html` 可作为隔离测试页在支持本地 HTML 的浏览器打开。此步骤未在真实 iPhone Safari 验收；如需 https 测试站点，只能在受控**私有**测试环境部署不含内部成本资料的 `web_test` 单独目录，不上传整个本 ZIP。

## 质量及安全标准
- 成功 FORTE 样本：JPG/RGB、1254x1254、CSV UTF-8 13列分号、每包不超过25款。
- AI 修图时必须保留经核实尺寸、容积、数量、品牌及规格；不能把 AI 重绘文字冒充原始证据。
- 无可靠真实条码、售价、数量、人工图片确认和可信在线查重时保持 `complete=false`，不生成正式 products.csv，不发起发布请求。
- P1-B 专用 AI 抠图与 P2 真实性未完成模型和真实设备测试。修图预览仅供审核。
- **特别注意**：历史 P1-A V3 网页与 V2 后端不是自动连接的单体软件；本包是可复验的独立组件集合，仍待实现网页→后端受控交接。

## 数据安全
FORTE 参照文件含价格成本等私有数据，文件仅供用户本地备份。公开工作台不得上传任何含采购价、成本、毛利、凭据的文件。
