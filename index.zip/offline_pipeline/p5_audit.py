#!/usr/bin/env python3
"""D.L.D BAZAR offline P5 audit. Pure read-only, NEVER generates publishable products.csv."""
import csv, io, json, zipfile, os, sys, re, hashlib, argparse
from pathlib import Path
from collections import Counter
from PIL import Image
HEADERS=['Référence fournisseur','Code-barres','Nom du produit (FR)','Catégorie','Quantité','Prix d’achat HT (€)','Prix de vente TTC (€)','Total achat HT (€)','Description originale (IT)','Prix brut HT (€)','Remise (%)','Image (URL ou nom de fichier)','Correspondance prix']
def key(s):
 s=re.sub(r'\s+','',str(s or ''))
 return s.lstrip('0') or '0' if s else ''
def ean13_valid(s):
 return len(s)==13 and s.isdigit() and ((10-(sum(int(s[i])*(1 if i%2==0 else 3) for i in range(12))%10))%10)==int(s[-1])
def number(s):
 try:return float(str(s).replace(',','.'))
 except:return None
def inspect(csv_file, image_archive=None, live_proof=None, public_catalog=None):
 # live_proof is intentionally not accepted as trustworthy simply by file availability.
 # An actual backend must independently authenticate, verify freshness, and re-check before write.
 with open(csv_file,encoding='utf-8-sig',newline='') as f:
  rows=list(csv.reader(f,delimiter=';'))
 if not rows:return {'fatal':'empty CSV','complete':False,'publish_requests':0}
 if rows[0]!=HEADERS:return {'fatal':'FORTE header mismatch','complete':False,'publish_requests':0,'expected_headers':HEADERS,'actual_headers':rows[0]}
 data=[]
 archive=None
 if image_archive:
  archive=zipfile.ZipFile(image_archive)
  images={i.filename:i for i in archive.infolist() if not i.is_dir()}
 else:images={}
 for idx,r in enumerate(rows[1:],2):
  reasons=[]
  if len(r)!=13:reasons.append('COLUMN_COUNT_NOT_13')
  r=(r+['']*13)[:13];d=dict(zip(HEADERS,r))
  ref=d[HEADERS[0]].strip();barcode=d[HEADERS[1]].strip();name=d[HEADERS[2]].strip();category=d[HEADERS[3]].strip();qty=number(d['Quantité']);sale=number(d['Prix de vente TTC (€)']);path=d['Image (URL ou nom de fichier)'].strip()
  if not ref:reasons.append('ITEM_CODE_MISSING')
  if not barcode:reasons.append('BARCODE_MISSING')
  elif not barcode.isdigit() or len(barcode)<8:reasons.append('BARCODE_INVALID')
  elif len(barcode)==13 and not ean13_valid(barcode):reasons.append('EAN13_CHECKDIGIT_INVALID')
  if not name:reasons.append('FRENCH_NAME_MISSING')
  if not category:reasons.append('CATEGORY_MISSING')
  if qty is None or qty<=0:reasons.append('QUANTITY_UNVERIFIED')
  if sale is None or sale<=0:reasons.append('SALE_PRICE_UNVERIFIED')
  if not path:reasons.append('IMAGE_MISSING')
  elif not archive:reasons.append('IMAGE_NOT_VERIFIED')
  elif path not in images:reasons.append('IMAGE_FILE_ABSENT')
  else:
   try:
    with archive.open(path) as f:
     im=Image.open(io.BytesIO(f.read()));im.load()
    if im.format!='JPEG' or im.size!=(1254,1254) or im.mode!='RGB':reasons.append('IMAGE_FORMAT_NOT_FORTE_STANDARD')
   except Exception:reasons.append('IMAGE_UNREADABLE')
  # independent approvals, barcode-to-photo authenticity and server-side duplicate verification unavailable
  reasons.extend(['IMAGE_AUTHENTICITY_UNVERIFIED','MANUAL_APPROVAL_MISSING','LIVE_DUPLICATE_CHECK_UNVERIFIED'])
  data.append({'row':idx,'supplier_ref':ref,'barcode':barcode,'product_fr':name,'image':path,'reasons':reasons,'status':'MANUAL_REVIEW'})
 if archive:archive.close()
 barcodes=Counter(key(x['barcode']) for x in data if x['barcode'])
 refs=Counter(x['supplier_ref'] for x in data if x['supplier_ref'])
 for x in data:
  if x['barcode'] and barcodes[key(x['barcode'])]>1:x['reasons'].append('DUPLICATE_BARCODE_IN_BATCH')
  if x['supplier_ref'] and refs[x['supplier_ref']]>1:x['reasons'].append('DUPLICATE_ITEM_CODE_IN_BATCH')
 if len(data)>25:
  for x in data:x['reasons'].append('FORTE_PACKAGE_MAX_25_EXCEEDED')
 # prohibit any release or 'ready' state without real authenticated server check
 return {'schema':'DLD-P5-v1','complete':False,'publish_requests':0,'upload_ready_count':0,'total':len(data),'manual_review_count':len(data),'live_check':'NOT_PERFORMED','reason':'No verified live store credentials, explicit individual approval, or images proven authentic','items':data}
def main():
 p=argparse.ArgumentParser();p.add_argument('--csv',required=True);p.add_argument('--images-zip');p.add_argument('--out',default='audit_result.json');args=p.parse_args()
 r=inspect(args.csv,args.images_zip)
 Path(args.out).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'complete':r['complete'],'total':r.get('total'),'manual_review_count':r.get('manual_review_count'),'upload_ready_count':r.get('upload_ready_count'),'publish_requests':r['publish_requests']},ensure_ascii=False))
if __name__=='__main__':main()
