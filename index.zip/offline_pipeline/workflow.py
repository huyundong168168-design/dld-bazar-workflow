#!/usr/bin/env python3
"""DLD BAZAR offline screenshot -> review ZIP. NEVER publishes or outputs products.csv."""
from pathlib import Path
import argparse,csv,io,zipfile,json,re,hashlib
from PIL import Image,ImageEnhance,ImageFilter,ImageOps
HEADERS=['Référence fournisseur','Code-barres','Nom du produit (FR)','Catégorie','Quantité','Prix d’achat HT (€)','Prix de vente TTC (€)','Total achat HT (€)','Description originale (IT)','Prix brut HT (€)','Remise (%)','Image (URL ou nom de fichier)','Correspondance prix']
REFS=['8101681','8101682','8101683','8101684','8101685','8101686']
SIZES=[12,16,20,25,30,40]
# Screenshot layout measured from supplied IMG_2971.jpeg. Fixed-layout pilot only.
RECTS=[(8,164,349,404),(357,164,700,404),(8,672,349,905),(357,672,700,905),(8,1197,349,1453),(357,1197,700,1453)]

def render(im, box):
    crop=im.crop(box).convert('RGB')
    # Conservative photo correction, preserving all visible size and packaging text; NO AI or text redraw.
    crop=ImageEnhance.Contrast(crop).enhance(1.035)
    crop=crop.filter(ImageFilter.UnsharpMask(radius=1.0,percent=65,threshold=4))
    out=Image.new('RGB',(1254,1254),'white'); crop.thumbnail((1194,1194),Image.Resampling.LANCZOS)
    out.paste(crop,((1254-crop.width)//2,(1254-crop.height)//2))
    bio=io.BytesIO();out.save(bio,format='JPEG',quality=92,subsampling=0)
    return bio.getvalue()

def run(source, output, limit=6):
    if limit<1 or limit>6:raise ValueError('This pilot supports 1 to 6 items from the supplied screenshot')
    src=Path(source);img=Image.open(src).convert('RGB')
    if img.size!=(709,1536):raise ValueError(f'Unexpected screenshot dimensions: {img.size}; fail closed (layout template only)')
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    originals=[]; photos=[]; rows=[];review=[]
    for i,(r,size,rect) in enumerate(zip(REFS,SIZES,RECTS)):
        if i>=limit:break
        sample=img.crop(rect);b=io.BytesIO();sample.save(b,format='JPEG',quality=95)
        originals.append((f'originals/{r}.jpg',b.getvalue()))
        photos.append((f'images_REVIEW_ONLY/{r}_PREVIEW.jpg',render(img,rect)))
        rows.append([r,'',f'Vis tête bombée cruciforme M4 x {size} mm avec écrous','Quincaillerie','','','','','','','','','NOT VERIFIED'])
        review.append([r,f'M4 x {size} mm','', 'NOT VERIFIED', 'NOT VERIFIED','NOT VERIFIED','NOT VERIFIED','NOT VERIFIED','PENDING','PHOTO_IS_ENHANCED_SCREENSHOT_NOT_AI_REMOVED','NO LIVE CHECK'])
    csv_str=io.StringIO();writer=csv.writer(csv_str,delimiter=';',lineterminator='\r\n');writer.writerow(HEADERS);writer.writerows(rows)
    review_str=io.StringIO();writer=csv.writer(review_str,delimiter=';',lineterminator='\r\n');writer.writerow(['reference','protected_dimension','ean','price','quantity','authenticity','manual_approval','live_duplicate_check','status','image_note','release']);writer.writerows(review)
    meta={'schema':'DLD-PILOT-1','mode':'ISOLATED_REVIEW_ONLY','source':src.name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'total':limit,'complete':False,'upload_ready_count':0,'publish_requests':0,'p1a':'TEMPLATE_SPLIT_PILOT','p1b':'NOT_DONE_NO_REAL_SEGMENTATION','p2':'CONSERVATIVE_ENHANCEMENT_ONLY','image_quality':'NOT_FORTE_VERIFIED','live_store_check':'NOT_DONE','protected_sizes_mm':SIZES[:limit]}
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,b in originals+photos:z.writestr(name,b)
        z.writestr('products_DRAFT_DO_NOT_UPLOAD.csv','\ufeff'+csv_str.getvalue())
        z.writestr('review.csv','\ufeff'+review_str.getvalue())
        z.writestr('audit.json',json.dumps(meta,ensure_ascii=False,indent=2))
        z.writestr('DO_NOT_UPLOAD.txt','REVIEW ONLY. NO validated barcodes/prices/quantity/live duplicate query. Image files are enhanced screenshot crops, not verified AI cutouts.\n')
    return meta

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--out',required=True);ap.add_argument('--limit',type=int,default=6);args=ap.parse_args()
    print(json.dumps(run(args.source,args.out,args.limit),ensure_ascii=False,indent=2))
