#!/usr/bin/env python3
"""DLD BAZAR P6: source image/spec immutability and release fail-closed. NO publication network calls."""
import sys,json,re,hashlib,zipfile,io,os,argparse
from pathlib import Path
from PIL import Image

def inspect(root:Path, candidate:dict, manifest:dict):
 problems=[]
 byref={x['supplier_ref']:x for x in manifest['records']}
 ref=str(candidate.get('supplier_ref',''))
 src=byref.get(ref)
 if not src:return ['UNKNOWN_SUPPLIER_REF']
 org=root/src['source_file']
 if not org.is_file() or hashlib.sha256(org.read_bytes()).hexdigest()!=src['source_sha256']:
  problems.append('SOURCE_ORIGINAL_MISSING_OR_CHANGED')
 if candidate.get('source_sha256')!=src['source_sha256']: problems.append('PROVENANCE_MISMATCH')
 # Provenance: AI-generated text is not evidence of factual product specifications.
 if candidate.get('method') in ('generative','ai_redraw','unknown',''):
  problems.append('GENERATIVE_OR_UNKNOWN_RENDER_REQUIRES_MANUAL_SPEC_REVIEW')
 if candidate.get('length')!=src['dimensions_verified']['length'] or candidate.get('diameter')!=src['dimensions_verified']['diameter']:
  problems.append('DIMENSIONS_MISSING_OR_CHANGED')
 capacity=src['capacity_verified']
 if capacity is None:
  if candidate.get('capacity') not in (None,''):
   problems.append('UNSUPPORTED_CAPACITY_INSERTED')
 elif candidate.get('capacity')!=capacity:problems.append('CAPACITY_MISSING_OR_CHANGED')
 # Text verification evidence must be human-signed or from a verifiable independent source.
 if not candidate.get('spec_verified_by_human',False):problems.append('VISIBLE_SPEC_NOT_VERIFIED_BY_HUMAN')
 if not candidate.get('authenticity_verified_by_human',False):problems.append('PRODUCT_APPEARANCE_NOT_VERIFIED')
 if candidate.get('pack_count') and src['pack_count']=='UNVERIFIED_FROM_PHOTO':problems.append('PACK_COUNT_NOT_SOURCE_VERIFIED')
 if not candidate.get('ean_verified'):problems.append('EAN_UNVERIFIED')
 if not candidate.get('price_verified'):problems.append('PRICE_UNVERIFIED')
 if not candidate.get('stock_qty_verified'):problems.append('STOCK_UNVERIFIED')
 if not candidate.get('live_store_check_server_verified'):problems.append('LIVE_DUPLICATE_CHECK_NOT_SERVER_VERIFIED')
 img=candidate.get('image_file')
 if not img:problems.append('OUTPUT_IMAGE_MISSING')
 else:
  p=(root/img).resolve()
  if root.resolve() not in p.parents:problems.append('UNSAFE_IMAGE_PATH')
  elif not p.is_file():problems.append('OUTPUT_IMAGE_NOT_FOUND')
  else:
   try:
    im=Image.open(p)
    if im.format!='JPEG' or im.mode!='RGB' or im.size!=(1254,1254):problems.append('IMAGE_NOT_FORTE_FORMAT')
   except Exception:problems.append('OUTPUT_IMAGE_UNREADABLE')
 return problems

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',default='.');ap.add_argument('--candidates',default='test_candidates.json');ap.add_argument('--out',default='validation_results.json');a=ap.parse_args()
 root=Path(a.root).resolve();manifest=json.loads((root/'protected_specs.json').read_text(encoding='utf8'))
 cs=json.loads((root/a.candidates).read_text(encoding='utf8'))
 results=[{'supplier_ref':c.get('supplier_ref'),'blocked':bool(p:=inspect(root,c,manifest)),'reasons':p} for c in cs]
 out={'schema':'DLD-SPEC-GATE-v1','complete':False,'publish_requests':0,'total':len(results),'blocked_count':sum(x['blocked'] for x in results),'items':results,'note':'This is an offline check; passing local rules never authorizes publication.'}
 (root/a.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({k:out[k] for k in ('total','blocked_count','complete','publish_requests')},ensure_ascii=False))
if __name__=='__main__':main()
