from pathlib import Path
from integrated_review import pipeline
import zipfile,json,csv,io,sys,hashlib, tempfile
from PIL import Image

def verify25(forte):
  with zipfile.ZipFile(forte) as z:
   assert z.testzip() is None
   rows=list(csv.reader(io.StringIO(z.read('products.csv').decode('utf-8-sig')),delimiter=';'))
   assert len(rows)==26 and len(rows[0])==13
   imgs=[n for n in z.namelist() if n.startswith('images/') and n.endswith('.jpg')]
   assert len(imgs)==25
   for n in imgs:
    im=Image.open(io.BytesIO(z.read(n)));assert im.format=='JPEG' and im.mode=='RGB' and im.size==(1254,1254)
   return {'type':'FORTE_REFERENCE_STRUCTURE','count':25,'result':'PASS','note':'Reference package only, not new screenshot pipeline'}

def test(src,forte,output_dir):
  output_dir.mkdir(exist_ok=True,parents=True)
  results=[]
  for n in [1,5,6]:
   path=output_dir/f'isolated_review_{n}.zip';r=pipeline(src,path,n)
   with zipfile.ZipFile(path) as z:
    assert z.testzip() is None and 'products.csv' not in z.namelist()
    assert len([x for x in z.namelist() if x.startswith('images_REVIEW_ONLY/')])==n
    data=json.loads(z.read('audit/integrated_audit.json'))
    assert not data['complete'] and data['publish_requests']==0 and data['upload_ready_count']==0
    assert data['manual_review_count']==n
    assert all('LIVE_DUPLICATE_CHECK_UNVERIFIED' in x['reasons'] for x in data['items'])
    assert all('P6_IMAGE_SPEC_VISUAL_COMPARISON_UNVERIFIED' in x['reasons'] for x in data['items'])
   results.append({'type':'INTEGRATED_REAL_SCREENSHOT','count':n,'result':'PASS','publish_requests':0,'upload_ready':0})
  try:pipeline(src,output_dir/'unsupported_7.zip',7)
  except ValueError:results.append({'type':'UNSUPPORTED_LAYOUT_FAIL_CLOSED','count':7,'result':'PASS'})
  else:raise AssertionError('unsupported template was allowed')
  results.append(verify25(forte))
  report={'complete':False,'publish_requests':0,'passed':len(results),'failed':0,'tests':results,'warning':'P1-B/P2 AI inference, 25 screenshot end-to-end and live read-only duplicate query are NOT verified'}
  (output_dir/'TEST_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
  return report

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--screenshot',required=True);p.add_argument('--forte',required=True);p.add_argument('--output-dir',default='test_output');a=p.parse_args()
 print(json.dumps(test(Path(a.screenshot),Path(a.forte),Path(a.output_dir)),ensure_ascii=False,indent=2))
