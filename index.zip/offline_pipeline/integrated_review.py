#!/usr/bin/env python3
"""DLD BAZAR integrated offline reviewer. No network, no publishable products.csv."""
from pathlib import Path
import tempfile, json, zipfile, csv, io, hashlib, re, argparse
from PIL import Image
from workflow import run as split_run, HEADERS
from p5_audit import inspect as p5_inspect

EXPECTED_SIZES_MM=[12,16,20,25,30,40]

def verify_spec(ref:str, frname:str):
    idx=int(ref[-1])-1 if re.fullmatch(r'810168[1-6]',ref or '') else -1
    if idx not in range(6):return ['UNKNOWN_REF_NEEDS_REVIEW']
    size=EXPECTED_SIZES_MM[idx]
    # only validate draft text unchanged; image OCR not verified
    return [] if f'M4 x {size} mm' in frname else ['PROTECTED_SPEC_IN_NAME_CHANGED']

def pipeline(source, dest, limit=6):
    source=Path(source);dest=Path(dest)
    with tempfile.TemporaryDirectory(prefix='dld-e2e-') as td:
        td=Path(td)
        candidate=td/'candidate.zip'
        evidence=split_run(source,candidate,limit)
        with zipfile.ZipFile(candidate) as zin:
            drafts=zin.read('products_DRAFT_DO_NOT_UPLOAD.csv')
            rows=list(csv.DictReader(io.StringIO(drafts.decode('utf-8-sig')),delimiter=';'))
            pics={n:zin.read(n) for n in zin.namelist() if n.startswith('images_REVIEW_ONLY/')}
            spec=[]
            for r in rows:
                ref=r[HEADERS[0]]; name=r[HEADERS[2]]
                spec.append({'reference':ref,'name':name,'protected_size_check':verify_spec(ref,name),'capacity':'NOT_APPLICABLE','photo_authenticity':'NOT_VERIFIED','photo_has_verified_specs':False})
            # P5 requires archive with paths specified in input; drafts leave image blank; all are blocked.
            csvfile=td/'draft.csv';csvfile.write_bytes(drafts)
            p5=p5_inspect(csvfile)
            p5['items']=[{**item,'reasons':list(dict.fromkeys(item['reasons']+spec[i]['protected_size_check']+['P1B_SEGMENTATION_UNVERIFIED','P2_IMAGE_QUALITY_UNVERIFIED','P6_IMAGE_SPEC_VISUAL_COMPARISON_UNVERIFIED']))} for i,item in enumerate(p5['items'])]
            p5['mode']='ISOLATED_INTEGRATED_V2'
            p5['complete']=False;p5['publish_requests']=0;p5['upload_ready_count']=0
            p5['manual_review_count']=len(rows)
            p5['protected_specs']=spec
            p5['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
            p5['image_previews_total']=len(pics)
            p5['artifacts_verified']={'candidate_archive_crc':zin.testzip() is None,'image_previews':[]}
            for n,b in pics.items():
                im=Image.open(io.BytesIO(b))
                p5['artifacts_verified']['image_previews'].append({'name':n,'jpeg_ok':im.format=='JPEG' and im.mode=='RGB' and im.size==(1254,1254),'sha256':hashlib.sha256(b).hexdigest()})
            if len(rows)!=limit or len(pics)!=limit:raise AssertionError('candidate count mismatch')
            if any(x['status']!='MANUAL_REVIEW' for x in p5['items']):raise AssertionError('unsafe release status')
            if any(not x['reasons'] for x in p5['items']):raise AssertionError('unblocked item')
            if any(not x['jpeg_ok'] for x in p5['artifacts_verified']['image_previews']):raise AssertionError('bad image preview')
            dest.parent.mkdir(parents=True,exist_ok=True)
            with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as zout:
                # Never use formal products.csv filename in review-only exports
                zout.writestr('draft/products_DRAFT_DO_NOT_UPLOAD.csv',drafts)
                for n in zin.namelist():
                    if n.startswith('originals/') or n.startswith('images_REVIEW_ONLY/'):
                        zout.writestr(n,zin.read(n))
                zout.writestr('audit/integrated_audit.json',json.dumps(p5,ensure_ascii=False,indent=2))
                zout.writestr('audit/protected_specs_review.json',json.dumps(spec,ensure_ascii=False,indent=2))
                zout.writestr('DO_NOT_UPLOAD.txt','ISOLATED REVIEW ONLY. No verified EAN, prices, quantity, image authenticity, live-store server duplicate check, or publisher. Never upload this ZIP to the store.\n')
        return {'count':len(rows),'blocked':len([x for x in p5['items'] if x['reasons']]),'preview_jpg':len(pics),'published_requests':0,'complete':False,'output':str(dest)}

if __name__=='__main__':
    pa=argparse.ArgumentParser();pa.add_argument('--screenshot',required=True);pa.add_argument('--out',required=True);pa.add_argument('--count',type=int,default=6)
    a=pa.parse_args();print(json.dumps(pipeline(a.screenshot,a.out,a.count),ensure_ascii=False,indent=2))
